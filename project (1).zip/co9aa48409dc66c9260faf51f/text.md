A unique place

We will learn about living in microgravity, surviving away from our own planet, and more, all while staying close enough to Earth for easy communication and assistance if needed.


So familiar, yet so different

The moon is something we all know, but so few have visited, and which is totally different from anything we've ever explored before.